#!/bin/bash
pkill -f "NeonMon/app/neonmon.py" 2>/dev/null || true
rm -rf "$HOME/Library/Application Support/NeonMon" "$HOME/Applications/NeonMon.app"
echo "NeonMon has been removed."
