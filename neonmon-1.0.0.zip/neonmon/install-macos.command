#!/bin/bash
# Install NeonMon on macOS for the current user (no admin rights needed).
# Run from Terminal:  bash install-macos.command
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
SUP="$HOME/Library/Application Support/NeonMon"
APP="$HOME/Applications/NeonMon.app"

echo "==> Looking for Python 3.8+"
PY=""
for c in python3 /opt/homebrew/bin/python3 /usr/local/bin/python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' >/dev/null 2>&1; then
    PY="$c"; break
  fi
done
if [ -z "$PY" ]; then
  echo "!! Python 3 is required."
  echo "   Install it with:  xcode-select --install"
  echo "   or download it from https://www.python.org/downloads/macos/ and run this installer again."
  exit 1
fi
echo "    using: $PY ($("$PY" --version))"

echo "==> Creating virtual environment"
mkdir -p "$SUP"
rm -rf "$SUP/venv"
"$PY" -m venv "$SUP/venv"
"$SUP/venv/bin/python" -m pip install --quiet --upgrade pip
"$SUP/venv/bin/python" -m pip install --quiet psutil
"$SUP/venv/bin/python" -m pip install --quiet pywebview \
  || echo "!! pywebview not installed; NeonMon will open in Chrome/Edge or Safari instead."

echo "==> Copying files"
rm -rf "$SUP/app"
mkdir -p "$SUP/app"
cp -R "$SRC/web" "$SRC/server.py" "$SRC/neonmon.py" "$SRC/icon.svg" "$SUP/app/"

echo "==> Creating $APP"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$SRC/icon.icns" "$APP/Contents/Resources/icon.icns"
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>NeonMon</string>
  <key>CFBundleDisplayName</key><string>NeonMon</string>
  <key>CFBundleIdentifier</key><string>local.neonmon.app</string>
  <key>CFBundleVersion</key><string>1.0.0</string>
  <key>CFBundleShortVersionString</key><string>1.0.0</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>NeonMon</string>
  <key>CFBundleIconFile</key><string>icon</string>
  <key>LSMinimumSystemVersion</key><string>10.13</string>
  <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST
cat > "$APP/Contents/MacOS/NeonMon" <<LAUNCH
#!/bin/bash
exec "$SUP/venv/bin/python" "$SUP/app/neonmon.py" "\$@"
LAUNCH
chmod +x "$APP/Contents/MacOS/NeonMon"
touch "$APP"

echo
echo "Done! Open NeonMon from Launchpad, Spotlight (Cmd+Space, type NeonMon)"
echo "or the Applications folder in your home directory."
