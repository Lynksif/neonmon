@echo off
rem Double-click this file to install NeonMon on Windows.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-windows.ps1"
pause
