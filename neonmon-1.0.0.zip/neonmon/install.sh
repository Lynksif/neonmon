#!/usr/bin/env bash
# Install NeonMon for the current user (root is only needed for the apt step).
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/neonmon"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"

echo "==> Installing dependencies (psutil + GTK WebKit window)"
sudo apt-get install -y python3 python3-psutil python3-gi gir1.2-gtk-3.0 lm-sensors \
  || echo "!! apt failed on the base packages, check your network / apt sources."
sudo apt-get install -y gir1.2-webkit2-4.1 2>/dev/null \
  || sudo apt-get install -y gir1.2-webkit2-4.0 2>/dev/null \
  || echo "!! Could not install WebKit; NeonMon will open in Chrome/Chromium or your default browser."

echo "==> Copying files to $DEST"
rm -rf "$DEST"
mkdir -p "$DEST" "$BIN" "$APPS"
cp -r "$SRC/server.py" "$SRC/neonmon.py" "$SRC/icon.svg" "$SRC/web" "$DEST/"

cat > "$BIN/neonmon" <<EOS
#!/usr/bin/env bash
exec python3 "$DEST/neonmon.py" "\$@"
EOS
chmod +x "$BIN/neonmon"

cat > "$APPS/neonmon.desktop" <<EOS
[Desktop Entry]
Type=Application
Name=NeonMon
Comment=Dashboard-style system monitor (CPU, RAM, GPU, network, disks)
Exec=$BIN/neonmon
Icon=$DEST/icon.svg
Terminal=false
Categories=System;Monitor;
Keywords=monitor;btop;cpu;ram;gpu;
StartupWMClass=NeonMon
EOS
update-desktop-database "$APPS" 2>/dev/null || true

echo
echo "Done! Open NeonMon from the app menu (press Super, type NeonMon)"
echo "or run: neonmon"
