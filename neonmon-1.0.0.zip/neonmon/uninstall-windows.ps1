# Remove NeonMon for the current Windows user.
$Dest = Join-Path $env:LOCALAPPDATA "NeonMon"
Get-CimInstance Win32_Process -Filter "Name like 'python%'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like "*NeonMon*neonmon.py*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Remove-Item -Recurse -Force $Dest -ErrorAction SilentlyContinue
Remove-Item -Force (Join-Path ([Environment]::GetFolderPath("Programs")) "NeonMon.lnk") -ErrorAction SilentlyContinue
Remove-Item -Force (Join-Path ([Environment]::GetFolderPath("Desktop"))  "NeonMon.lnk") -ErrorAction SilentlyContinue
Write-Host "NeonMon has been removed."
