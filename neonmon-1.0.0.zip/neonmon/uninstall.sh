#!/usr/bin/env bash
rm -rf "$HOME/.local/share/neonmon" "$HOME/.local/bin/neonmon" "$HOME/.local/share/applications/neonmon.desktop"
echo "NeonMon has been removed."
