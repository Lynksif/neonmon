#!/usr/bin/env python3
"""NeonMon launcher: starts the backend and shows the dashboard in its own window.

Window strategy (first one that works):
  1. Linux: native GTK window with WebKit (python3-gi + gir1.2-webkit2-4.1)
  2. pywebview (Windows: Edge WebView2, macOS: WKWebView), if installed
  3. Chrome/Edge/Brave/Chromium in --app mode (own window, no tabs)
  4. Default browser; server keeps running until Ctrl+C
Use --browser to skip the native window, --no-window to run the server only.
"""
import argparse
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import webbrowser

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import start_server  # noqa: E402

TITLE = "NeonMon"
HERE = os.path.dirname(os.path.abspath(__file__))
IS_WIN = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"


def port_busy(port):
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


def try_gtk(url, width, height):
    if IS_WIN or IS_MAC:
        return False
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        for ver in ("4.1", "4.0"):
            try:
                gi.require_version("WebKit2", ver)
                break
            except ValueError:
                continue
        from gi.repository import Gtk, WebKit2
    except (ImportError, ValueError):
        return False

    win = Gtk.Window(title=TITLE)
    win.set_default_size(width, height)
    icon = os.path.join(HERE, "icon.svg")
    if os.path.exists(icon):
        try:
            win.set_icon_from_file(icon)
        except Exception:
            pass
    view = WebKit2.WebView()
    view.set_background_color(_rgba("#07090a"))
    view.load_uri(url)
    win.add(view)
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
    return True


def _rgba(hexstr):
    from gi.repository import Gdk
    c = Gdk.RGBA()
    c.parse(hexstr)
    return c


def try_pywebview(url, width, height):
    try:
        import webview
    except Exception:
        return False
    try:
        webview.create_window(TITLE, url, width=width, height=height,
                              background_color="#07090a")
        webview.start()
        return True
    except Exception as exc:
        print("pywebview failed, falling back:", exc)
        return False


def _browser_candidates():
    names = ["google-chrome", "google-chrome-stable", "chromium",
             "chromium-browser", "brave-browser", "microsoft-edge", "vivaldi",
             "chrome", "msedge"]
    found = [shutil.which(n) for n in names]
    if IS_WIN:
        roots = [os.environ.get(k, "") for k in
                 ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")]
        rel = [r"Google\Chrome\Application\chrome.exe",
               r"Microsoft\Edge\Application\msedge.exe",
               r"BraveSoftware\Brave-Browser\Application\brave.exe"]
        found += [os.path.join(r, p) for r in roots if r for p in rel]
    if IS_MAC:
        found += [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
        ]
    return [f for f in found if f and os.path.isfile(f)]


def try_chromium(url, width, height):
    for exe in _browser_candidates():
        uid = os.getuid() if hasattr(os, "getuid") else os.environ.get("USERNAME", "user")
        profile = os.path.join(tempfile.gettempdir(), f"neonmon-{uid}")
        cmd = [exe, f"--app={url}", f"--window-size={width},{height}",
               f"--user-data-dir={profile}", "--no-first-run",
               "--class=NeonMon"]
        # Blocks until the app window is closed (dedicated profile).
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    return False


def open_default(url):
    webbrowser.open(url)
    print(f"Opened {url} in your browser. Press Ctrl+C to stop NeonMon.")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass


def main():
    ap = argparse.ArgumentParser(description="NeonMon system monitor")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--interval", type=float, default=1.0,
                    help="seconds between updates (default 1)")
    ap.add_argument("--browser", action="store_true",
                    help="skip the GTK window and open in a browser")
    ap.add_argument("--no-window", action="store_true",
                    help="run the server only (open http://127.0.0.1:PORT yourself)")
    ap.add_argument("--size", default="1480x940")
    args = ap.parse_args()
    w, h = (int(x) for x in args.size.lower().split("x"))

    url = f"http://127.0.0.1:{args.port}/"
    if port_busy(args.port):
        # Already running: just open another window onto it.
        print("NeonMon is already running, opening another window.")
    else:
        start_server(args.port, args.interval)
        time.sleep(0.3)
    print(f"NeonMon: {url}")

    if args.no_window:
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            return
    if not args.browser and (try_gtk(url, w, h) or try_pywebview(url, w, h)):
        return
    if try_chromium(url, w, h):
        return
    open_default(url)


if __name__ == "__main__":
    main()
