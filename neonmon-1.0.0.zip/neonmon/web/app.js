"use strict";
(() => {
  const $ = (id) => document.getElementById(id);
  const NS = "http://www.w3.org/2000/svg";
  const C = { neon: "#b8ff2b", n2: "#8fdc1c", g3: "#4f8f1a", g4: "#2c5212", track: "rgba(255,255,255,.06)" };
  const state = { procSort: "cpu", io: "net", filter: "", last: null };

  // ------------------------------------------------------------ helpers --
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  function bytes(n, dec = 1) {
    if (n == null || isNaN(n)) return "--";
    const u = ["B", "KB", "MB", "GB", "TB"];
    let i = 0;
    while (Math.abs(n) >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return n.toFixed(i === 0 ? 0 : dec) + " " + u[i];
  }
  const rate = (n) => bytes(n) + "/s";
  function splitUnit(str) { const p = str.split(" "); return [p[0], p.slice(1).join(" ")]; }
  function uptime(sec) {
    const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
    if (d > 0) return [d + "d " + h, "h"];
    return [h + "h " + m, "m"];
  }
  function el(tag, attrs = {}, parent) {
    const e = document.createElementNS(NS, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  }
  function levelClass(v, warn, hot) { return v >= hot ? "hot" : v >= warn ? "warn" : "ok"; }

  // ------------------------------------------------------- hero chip art --
  (function drawTraces() {
    const g = document.querySelector("#chipArt .traces");
    const paths = [];
    const sides = [
      (i) => [`M${115 + i * 18} 95 V${70 - (i % 2) * 18} H${100 + i * 26}`, [100 + i * 26, 70 - (i % 2) * 18]],
      (i) => [`M${115 + i * 18} 225 V${250 + (i % 2) * 18} H${120 + i * 22}`, [120 + i * 22, 250 + (i % 2) * 18]],
      (i) => [`M95 ${115 + i * 18} H${70 - (i % 2) * 18} V${100 + i * 26}`, [70 - (i % 2) * 18, 100 + i * 26]],
      (i) => [`M225 ${115 + i * 18} H${250 + (i % 2) * 18} V${120 + i * 22}`, [250 + (i % 2) * 18, 120 + i * 22]],
    ];
    sides.forEach((fn) => { for (let i = 0; i < 6; i++) paths.push(fn(i)); });
    paths.forEach(([d, end], idx) => {
      el("path", { d }, g);
      if (idx % 3 === 0) {
        const f = el("path", { d, class: "flow" }, g);
        f.style.animationDelay = (idx * 0.17) + "s";
      }
      el("circle", { cx: end[0], cy: end[1], r: 3 }, g);
    });
  })();

  // ---------------------------------------------------------------- rings --
  function drawRings(values) {
    const svg = $("rings");
    svg.innerHTML = "";
    const radii = [86, 66, 46], w = 14;
    const cols = [C.neon, C.n2, C.g3];
    values.forEach((v, i) => {
      const r = radii[i], circ = 2 * Math.PI * r;
      el("circle", { cx: 100, cy: 100, r, fill: "none", stroke: C.track, "stroke-width": w }, svg);
      if (v == null) return;
      const len = Math.max(0.01, Math.min(1, v / 100)) * circ;
      const arc = el("circle", {
        cx: 100, cy: 100, r, fill: "none", stroke: cols[i], "stroke-width": w, "stroke-linecap": "round",
        "stroke-dasharray": `${len} ${circ}`, transform: "rotate(-90 100 100)",
      }, svg);
      if (i === 0) arc.setAttribute("style", "filter: drop-shadow(0 0 6px rgba(184,255,43,.55))");
    });
    // center icon (chip)
    const g = el("g", { transform: "translate(88 88)", fill: "none", stroke: C.neon, "stroke-width": 2, "stroke-linecap": "round" }, svg);
    el("rect", { x: 4, y: 4, width: 16, height: 16, rx: 3 }, g);
    el("path", { d: "M9 0v4M15 0v4M9 20v4M15 20v4M0 9h4M0 15h4M20 9h4M20 15h4" }, g);
  }

  // ---------------------------------------------------------------- donut --
  function drawDonut(parts) {
    const svg = $("donut");
    svg.innerHTML = "";
    const r = 78, w = 30, circ = 2 * Math.PI * r, gap = 3;
    const total = parts.reduce((a, p) => a + p.v, 0) || 1;
    let off = 0;
    parts.forEach((p, i) => {
      const frac = p.v / total;
      const len = Math.max(0, frac * circ - gap);
      const s = el("circle", {
        cx: 100, cy: 100, r, fill: "none", stroke: p.c, "stroke-width": w,
        "stroke-dasharray": `${len} ${circ}`, "stroke-dashoffset": -off, transform: "rotate(-90 100 100)",
      }, svg);
      if (i === 0) s.setAttribute("style", "filter: drop-shadow(0 0 8px rgba(184,255,43,.35))");
      off += frac * circ;
    });
    el("circle", { cx: 100, cy: 100, r: 60, fill: "#0b0d0d" }, svg);
  }

  // ----------------------------------------------------------- line chart --
  function lineChart(host, series, opts = {}) {
    const W = host.clientWidth, H = host.clientHeight;
    if (!W || !H) return;
    const padL = 42, padR = 12, padT = 12, padB = 22;
    const n = Math.max(...series.map((s) => s.data.length), 2);
    let max = opts.max;
    if (max == null) {
      max = Math.max(1, ...series.flatMap((s) => s.data.filter((v) => v != null)));
      max *= 1.15;
    }
    const x = (i) => padL + (i / (n - 1)) * (W - padL - padR);
    const y = (v) => padT + (1 - v / max) * (H - padT - padB);
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    const defs = el("defs", {}, svg);

    const axis = el("g", { class: "axis" }, svg);
    for (let k = 0; k <= 4; k++) {
      const v = (max * k) / 4, yy = y(v);
      el("line", { x1: padL, x2: W - padR, y1: yy, y2: yy, "stroke-dasharray": k === 0 ? "" : "3 5" }, axis);
      const t = el("text", { x: padL - 8, y: yy + 3, "text-anchor": "end" }, axis);
      t.textContent = opts.fmt ? opts.fmt(v) : Math.round(v);
    }
    const labels = opts.xLabels || ["-60s", "-45s", "-30s", "-15s", "now"];
    labels.forEach((l, k) => {
      const t = el("text", { x: padL + (k / (labels.length - 1)) * (W - padL - padR), y: H - 4, "text-anchor": k === 0 ? "start" : k === labels.length - 1 ? "end" : "middle" }, axis);
      t.textContent = l;
    });

    series.forEach((s, si) => {
      const off = n - s.data.length;
      const pts = s.data.map((v, i) => (v == null ? null : [x(i + off), y(Math.min(v, max))])).filter(Boolean);
      if (pts.length < 2) return;
      const d = smooth(pts);
      if (s.fill) {
        const gid = `g${Math.random().toString(36).slice(2)}`;
        const lg = el("linearGradient", { id: gid, x1: 0, y1: 0, x2: 0, y2: 1 }, defs);
        el("stop", { offset: 0, "stop-color": s.color, "stop-opacity": 0.28 }, lg);
        el("stop", { offset: 1, "stop-color": s.color, "stop-opacity": 0 }, lg);
        el("path", { d: `${d} L${pts[pts.length - 1][0]} ${y(0)} L${pts[0][0]} ${y(0)} Z`, fill: `url(#${gid})` }, svg);
      }
      el("path", {
        d, fill: "none", stroke: s.color, "stroke-width": s.width || 2.4, "stroke-linecap": "round",
        "stroke-dasharray": s.dash || "", style: si === 0 ? "filter: drop-shadow(0 0 5px rgba(184,255,43,.6))" : "",
      }, svg);
      if (s.dots) {
        const step = Math.max(1, Math.floor(pts.length / 7));
        pts.forEach((p, i) => { if (i % step === 0 && i !== pts.length - 1) el("circle", { cx: p[0], cy: p[1], r: 3.5, fill: s.color }, svg); });
      }
      const last = pts[pts.length - 1];
      el("circle", { cx: last[0], cy: last[1], r: 9, fill: s.color, opacity: 0.2 }, svg);
      el("circle", { cx: last[0], cy: last[1], r: 5, fill: s.color }, svg);
    });
    host.replaceChildren(svg);
  }
  function smooth(p) {
    let d = `M${p[0][0]} ${p[0][1]}`;
    for (let i = 1; i < p.length; i++) {
      const [x0, y0] = p[i - 1], [x1, y1] = p[i];
      const mx = (x0 + x1) / 2;
      d += ` C${mx} ${y0} ${mx} ${y1} ${x1} ${y1}`;
    }
    return d;
  }

  // -------------------------------------------------------------- render --
  function render(s) {
    state.last = s;
    const st = s.static;
    const hr = new Date().getHours();
    const greet = hr < 12 ? "Good morning" : hr < 18 ? "Good afternoon" : "Good evening";
    $("greeting").textContent = `${greet}, ${st.user}`;
    $("heroSub").textContent = `${st.hostname} · ${st.os} · Kernel ${st.kernel}. ${st.cpu_model} (${st.cores_physical} cores / ${st.cores_logical} threads).`;
    $("topMeta").textContent = `${st.hostname}  ·  ${st.os}  ·  ${s.procs_count} processes`;

    // hero minis
    const t = s.cpu.temp;
    $("mTemp").textContent = t != null ? Math.round(t) : "--";
    $("mTempS").textContent = t == null ? "No sensor" : t >= 85 ? "Very hot" : t >= 70 ? "Warm" : "Normal";
    $("mTempS").className = "mini-state " + (t == null ? "" : levelClass(t, 70, 85));
    const load = s.cpu.load[0], cores = st.cores_logical || 1;
    $("mLoad").textContent = load.toFixed(2);
    const lr = load / cores;
    $("mLoadS").textContent = lr > 1 ? "Overloaded" : lr > 0.7 ? "Busy" : "Light";
    $("mLoadS").className = "mini-state " + levelClass(lr, 0.7, 1);
    const [uv, uu] = uptime(s.uptime);
    $("mUp").textContent = uv; $("mUpU").textContent = uu;
    $("mUpS").textContent = s.battery ? `Battery ${Math.round(s.battery.percent)}%${s.battery.plugged ? " ⚡" : ""}` : "Stable";
    $("chipVal").textContent = Math.round(s.cpu.total) + "%";
    $("chipGlow").setAttribute("opacity", (0.35 + s.cpu.total / 150).toFixed(2));

    // rings
    const gpu = s.gpus[0];
    const third = gpu && gpu.util != null ? { l: "GPU", v: gpu.util } : { l: "Swap", v: s.swap.total ? s.swap.percent : 0 };
    drawRings([s.cpu.total, s.mem.percent, third.v]);
    $("rCpu").textContent = Math.round(s.cpu.total);
    $("rMem").textContent = Math.round(s.mem.percent);
    $("rThird").textContent = Math.round(third.v);
    $("rThirdLbl").textContent = third.l;

    // memory donut
    const m = s.mem;
    const used = Math.max(0, m.total - m.available);
    const cache = Math.max(0, Math.min(m.cached, m.total - used));
    const free = Math.max(0, m.total - used - cache);
    drawDonut([{ v: used, c: C.neon }, { v: cache, c: C.g3 }, { v: free, c: C.g4 }]);
    const [uval, uunit] = splitUnit(bytes(used));
    $("memUsed").textContent = uval;
    $("memTotal").textContent = `${uunit} / ${bytes(m.total, 0)}`;
    const pct = (v) => Math.round((v / m.total) * 100) + "%";
    $("lgUsed").textContent = pct(used); $("lgUsedV").textContent = bytes(used);
    $("lgCache").textContent = pct(cache); $("lgCacheV").textContent = bytes(cache);
    $("lgFree").textContent = pct(free); $("lgFreeV").textContent = bytes(free);
    $("memPill").textContent = bytes(m.total, 0);
    $("swapBar").style.width = (s.swap.total ? s.swap.percent : 0) + "%";
    $("swapTxt").textContent = s.swap.total ? `${bytes(s.swap.used)} / ${bytes(s.swap.total, 0)}` : "None";

    // cores
    const pc = s.cpu.per_core;
    const maxV = Math.max(...pc), maxI = pc.indexOf(maxV);
    $("coreAvg").textContent = Math.round(s.cpu.total);
    $("coreMax").textContent = Math.round(maxV) + "%";
    $("coreMaxName").textContent = "Thread " + maxI;
    $("freqPill").textContent = s.cpu.freq ? (s.cpu.freq.current / 1000).toFixed(2) + " GHz" : "-- GHz";
    const host = $("cores");
    if (host.children.length !== pc.length) {
      host.innerHTML = pc.map((_, i) => `<div class="core"><div class="core-track"><div class="core-fill"></div></div><span class="core-lbl">${i}</span></div>`).join("");
    }
    [...host.children].forEach((c, i) => {
      c.classList.toggle("peak", i === maxI);
      c.querySelector(".core-fill").style.height = Math.max(3, pc[i]) + "%";
    });

    renderIO(s);

    // history
    $("hCpu").textContent = Math.round(s.cpu.total);
    $("hMem").textContent = Math.round(s.mem.percent);
    const hasGpu = s.history.gpu.some((v) => v != null);
    $("hGpuBox").style.display = hasGpu ? "" : "none";
    if (hasGpu) $("hGpu").textContent = Math.round(gpu.util);
    const hs = [
      { data: s.history.cpu, color: C.neon, fill: true, dots: true },
      { data: s.history.mem, color: C.g3, width: 2 },
    ];
    if (hasGpu) hs.push({ data: s.history.gpu, color: "#e8ffd0", width: 1.6, dash: "4 4" });
    lineChart($("histChart"), hs, { max: 100, fmt: (v) => Math.round(v) + "%" });

    renderProcs(s);
    renderDisks(s);
    renderSensors(s);
  }

  function renderIO(s) {
    const net = state.io === "net";
    const a = net ? s.history.rx : s.history.read;
    const b = net ? s.history.tx : s.history.write;
    $("ioTitle").textContent = net ? "Network" : "Disk I/O";
    $("ioMain").textContent = rate(net ? s.net.rx : s.disk_io.read);
    $("ioMainL").textContent = net ? "Download" : "Read";
    $("ioSecond").textContent = "↑ " + rate(net ? s.net.tx : s.disk_io.write);
    $("ioSecondL").textContent = net ? "Upload" : "Write";
    $("ioPeak").textContent = rate(Math.max(0, ...a, ...b));
    $("ioLgA").textContent = net ? `Down · total ${bytes(s.net.rx_total)}` : "Read";
    $("ioLgB").textContent = net ? `Up · total ${bytes(s.net.tx_total)}` : "Write";
    lineChart($("ioChart"), [
      { data: a, color: C.neon, fill: true, dots: true },
      { data: b, color: C.g3, width: 2 },
    ], { fmt: (v) => bytes(v, 1).replace(".0 ", " ").replace(" ", "") });
  }

  function renderProcs(s) {
    $("procCount").textContent = `· ${s.procs_count}`;
    const f = state.filter.toLowerCase();
    const list = s.procs.filter((p) => !f || p.name.toLowerCase().includes(f) || p.cmd.toLowerCase().includes(f)).slice(0, 30);
    $("procs").innerHTML = list.map((p) => {
      const main = state.procSort === "mem" ? bytes(p.rss) : p.cpu.toFixed(1) + "%";
      const barV = state.procSort === "mem" ? p.mem : Math.min(100, p.cpu);
      return `<li class="proc" title="${esc(p.cmd || p.name)}">
        <div class="proc-ico">${esc(p.name.charAt(0).toUpperCase())}</div>
        <div style="min-width:0"><div class="proc-name">${esc(p.name)}</div>
          <div class="proc-sub">PID ${p.pid} · ${esc(p.user)} · ${state.procSort === "mem" ? p.cpu.toFixed(1) + "% CPU" : bytes(p.rss)} · ${p.threads} threads</div></div>
        <div class="proc-val"><b>${main}</b><div class="bar"><i style="width:${Math.max(2, barV)}%"></i></div></div>
      </li>`;
    }).join("") || `<li class="empty">No matching processes</li>`;
  }

  function renderDisks(s) {
    const total = s.disks.reduce((a, d) => a + d.total, 0);
    $("diskPill").textContent = `${s.disks.length} partitions · ${bytes(total, 0)}`;
    $("disks").innerHTML = s.disks.map((d) => `
      <li class="disk">
        <div class="disk-head"><b>${esc(d.mount)}</b><span>${bytes(d.used)} / ${bytes(d.total)}</span></div>
        <div class="bar"><i style="width:${d.percent}%;${d.percent > 90 ? "background:linear-gradient(90deg,#a33,#ff5c4d)" : ""}"></i></div>
        <div class="disk-foot"><span>${esc(d.device)} · ${esc(d.fstype)}</span><span class="${levelClass(d.percent, 80, 90)}">${d.percent.toFixed(0)}%</span></div>
      </li>`).join("") || `<li class="empty">Could not read partitions</li>`;
  }

  function renderSensors(s) {
    $("gpuBox").innerHTML = s.gpus.map((g) => `
      <div class="gpu"><div class="gpu-name">${esc(g.name)}</div>
        <div class="gpu-grid">
          <div>Load<b>${g.util != null ? Math.round(g.util) + "%" : "--"}</b></div>
          <div>VRAM<b>${g.mem_total ? Math.round((g.mem_used / g.mem_total) * 100) + "%" : "--"}</b></div>
          <div>Temp<b>${g.temp != null ? Math.round(g.temp) + "°" : "--"}</b></div>
          <div>Power<b>${g.power != null ? Math.round(g.power) + "W" : "--"}</b></div>
        </div></div>`).join("");
    const temps = s.temps.slice().sort((a, b) => b.current - a.current);
    $("sensPill").textContent = temps.length ? `${temps.length} sensors` : "None";
    $("sensors").innerHTML = temps.map((t) => {
      const hot = t.critical || t.high || 100;
      return `<li class="sensor"><span title="${esc(t.chip)}">${esc(t.label)}</span>
        <div class="bar"><i style="width:${Math.min(100, (t.current / hot) * 100)}%"></i></div>
        <b class="${levelClass(t.current, 70, 85)}">${t.current.toFixed(0)}°C</b></li>`;
    }).join("") || (s.gpus.length ? "" : `<li class="empty">No temperature sensors found. On Pop!_OS try: sudo apt install lm-sensors && sudo sensors-detect</li>`);
  }

  // ------------------------------------------------------------- wiring --
  function seg(id, key, cb) {
    $(id).addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      [...$(id).children].forEach((x) => x.classList.toggle("on", x === b));
      state[key] = b.dataset.k;
      cb && cb();
    });
  }
  seg("ioSeg", "io", () => state.last && renderIO(state.last));
  seg("procSeg", "procSort", tick);
  $("procSearch").addEventListener("input", (e) => { state.filter = e.target.value; state.last && renderProcs(state.last); });
  window.addEventListener("resize", () => state.last && render(state.last));

  setInterval(() => { $("clock").textContent = new Date().toLocaleTimeString("en-GB"); }, 1000);

  let busy = false;
  async function tick() {
    if (busy) return;
    busy = true;
    try {
      const limit = state.filter ? 300 : 40;
      const r = await fetch(`/api/stats?sort=${state.procSort}&limit=${limit}`, { cache: "no-store" });
      render(await r.json());
      document.querySelector(".live").style.opacity = 1;
    } catch (e) {
      document.querySelector(".live").style.opacity = 0.3;
      console.error(e);
    } finally { busy = false; }
  }
  tick();
  setInterval(tick, 1000);
})();
