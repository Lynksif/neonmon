# Install NeonMon for the current Windows user (no admin rights needed).
$ErrorActionPreference = "Stop"
$Src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest = Join-Path $env:LOCALAPPDATA "NeonMon"

function Test-Python($exe, $extra) {
    try {
        $out = & $exe @extra -c "import sys; print(sys.version_info >= (3, 8))" 2>$null
        return ($LASTEXITCODE -eq 0 -and "$out".Trim() -eq "True")
    } catch { return $false }
}

function Find-Python {
    # Prefer the py launcher; "python" may be the Microsoft Store stub.
    if (Get-Command py -ErrorAction SilentlyContinue) {
        if (Test-Python "py" @("-3")) { return [pscustomobject]@{ Exe = "py"; Args = @("-3") } }
    }
    foreach ($c in @("python", "python3")) {
        $cmd = Get-Command $c -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source -notlike "*WindowsApps*" -and (Test-Python $c @())) { return [pscustomobject]@{ Exe = $c; Args = @() } }
    }
    $known = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe", "$env:ProgramFiles\Python3*\python.exe" -ErrorAction SilentlyContinue |
             Sort-Object FullName -Descending | Select-Object -First 1
    if ($known) { return [pscustomobject]@{ Exe = $known.FullName; Args = @() } }
    return $null
}

Write-Host "==> Looking for Python 3.8+"
$py = Find-Python
if (-not $py) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "==> Python not found, installing it with winget"
        winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
        $py = Find-Python
    }
    if (-not $py) {
        Write-Host "!! Python 3 is required. Install it from https://www.python.org/downloads/ and run this installer again." -ForegroundColor Red
        exit 1
    }
}
$pyExe = $py.Exe; $pyArgs = @($py.Args)
Write-Host "    using: $pyExe $($pyArgs -join ' ')"

Write-Host "==> Creating virtual environment in $Dest\venv"
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
& $pyExe @pyArgs -m venv "$Dest\venv"
$venvPy = "$Dest\venv\Scripts\python.exe"
& $venvPy -m pip install --quiet --upgrade pip
& $venvPy -m pip install --quiet psutil
if ($LASTEXITCODE -ne 0) { Write-Host "!! Could not install psutil" -ForegroundColor Red; exit 1 }
& $venvPy -m pip install --quiet pywebview
if ($LASTEXITCODE -ne 0) {
    Write-Host "!! pywebview not installed; NeonMon will open in an Edge/Chrome app window instead." -ForegroundColor Yellow
}

Write-Host "==> Copying files"
$App = Join-Path $Dest "app"
if (Test-Path $App) { Remove-Item -Recurse -Force $App }
New-Item -ItemType Directory -Force -Path $App | Out-Null
Copy-Item -Recurse -Force "$Src\web", "$Src\server.py", "$Src\neonmon.py", "$Src\icon.ico", "$Src\icon.svg" $App

Write-Host "==> Creating Start Menu and Desktop shortcuts"
$shell = New-Object -ComObject WScript.Shell
$targets = @(
    (Join-Path ([Environment]::GetFolderPath("Programs")) "NeonMon.lnk"),
    (Join-Path ([Environment]::GetFolderPath("Desktop"))  "NeonMon.lnk")
)
foreach ($lnk in $targets) {
    $s = $shell.CreateShortcut($lnk)
    $s.TargetPath       = "$Dest\venv\Scripts\pythonw.exe"
    $s.Arguments        = "`"$App\neonmon.py`""
    $s.WorkingDirectory = $App
    $s.IconLocation     = "$App\icon.ico"
    $s.Description      = "Dashboard-style system monitor"
    $s.Save()
}

Write-Host ""
Write-Host "Done! Open NeonMon from the Start Menu or the Desktop shortcut." -ForegroundColor Green
