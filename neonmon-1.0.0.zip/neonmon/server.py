#!/usr/bin/env python3
"""NeonMon - system monitor backend.

Collects stats with psutil once per second in a background thread and serves
them as JSON (/api/stats) plus the static dashboard (web/) on 127.0.0.1.
"""
import argparse
import getpass
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import threading
import time
from collections import deque
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

import psutil

HERE = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(HERE, "web")
HISTORY = 60  # seconds of history kept for charts


IS_WIN = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"
# Hide the console window that subprocesses would flash on Windows.
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _run(cmd, timeout=2):
    try:
        return subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout, creationflags=NO_WINDOW).stdout
    except Exception:
        return ""


def read_os_name():
    if IS_WIN:
        build = sys.getwindowsversion().build
        name = "Windows 11" if platform.release() == "10" and build >= 22000 \
            else f"Windows {platform.release()}"
        return f"{name} (build {build})"
    if IS_MAC:
        return f"macOS {platform.mac_ver()[0]}"
    try:
        with open("/etc/os-release") as f:
            data = dict(
                line.rstrip("\n").split("=", 1) for line in f if "=" in line
            )
        return data.get("PRETTY_NAME", "Linux").strip('"')
    except OSError:
        return platform.system()


def cpu_model():
    if IS_MAC:
        out = _run(["sysctl", "-n", "machdep.cpu.brand_string"]).strip()
        if out:
            return out
    if IS_WIN:
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                 r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
            return winreg.QueryValueEx(key, "ProcessorNameString")[0].strip()
        except OSError:
            pass
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    return line.split(":", 1)[1].strip()
    except OSError:
        pass
    return platform.processor() or "CPU"


# --------------------------------------------------------------------- GPU --
def gpu_nvidia():
    if not shutil.which("nvidia-smi"):
        return []
    try:
        out = _run(
            [
                "nvidia-smi",
                "--query-gpu=name,utilization.gpu,memory.used,memory.total,"
                "temperature.gpu,power.draw,power.limit,fan.speed,clocks.gr",
                "--format=csv,noheader,nounits",
            ],
        )
    except Exception:
        return []

    def num(v):
        try:
            return float(v)
        except ValueError:
            return None

    gpus = []
    for line in out.strip().splitlines():
        p = [x.strip() for x in line.split(",")]
        if len(p) < 9:
            continue
        gpus.append({
            "vendor": "NVIDIA", "name": p[0], "util": num(p[1]),
            "mem_used": (num(p[2]) or 0) * 1024 * 1024,
            "mem_total": (num(p[3]) or 0) * 1024 * 1024,
            "temp": num(p[4]), "power": num(p[5]), "power_limit": num(p[6]),
            "fan": num(p[7]), "clock": num(p[8]),
        })
    return gpus


def _read(path):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return None


def gpu_sysfs():
    """AMD (amdgpu) and Intel via /sys/class/drm."""
    gpus = []
    base = "/sys/class/drm"
    if not os.path.isdir(base):
        return gpus
    for card in sorted(os.listdir(base)):
        if not card.startswith("card") or "-" in card:
            continue
        dev = os.path.join(base, card, "device")
        vendor = _read(os.path.join(dev, "vendor"))
        if vendor not in ("0x1002", "0x8086"):
            continue
        busy = _read(os.path.join(dev, "gpu_busy_percent"))
        used = _read(os.path.join(dev, "mem_info_vram_used"))
        total = _read(os.path.join(dev, "mem_info_vram_total"))
        temp = None
        hw = os.path.join(dev, "hwmon")
        if os.path.isdir(hw):
            for h in os.listdir(hw):
                t = _read(os.path.join(hw, h, "temp1_input"))
                if t:
                    temp = int(t) / 1000
                    break
        if busy is None and vendor == "0x8086":
            # Intel iGPU exposes no simple busy counter; show it as present.
            pass
        gpus.append({
            "vendor": "AMD" if vendor == "0x1002" else "Intel",
            "name": ("AMD Radeon" if vendor == "0x1002" else "Intel Graphics")
            + f" ({card})",
            "util": float(busy) if busy else None,
            "mem_used": int(used) if used else None,
            "mem_total": int(total) if total else None,
            "temp": temp, "power": None, "power_limit": None,
            "fan": None, "clock": None,
        })
    return gpus


# --------------------------------------------------------------- collector --
class Collector:
    def __init__(self, interval=1.0):
        self.interval = interval
        self.lock = threading.Lock()
        self.snapshot = {}
        self.hist = {
            k: deque(maxlen=HISTORY)
            for k in ("cpu", "mem", "rx", "tx", "read", "write", "gpu")
        }
        self.procs = {}
        self.static = {
            "hostname": socket.gethostname(),
            "user": getpass.getuser(),
            "os": read_os_name(),
            "kernel": platform.release(),
            "arch": platform.machine(),
            "cpu_model": cpu_model(),
            "cores_physical": psutil.cpu_count(logical=False),
            "cores_logical": psutil.cpu_count(logical=True),
            "boot_time": psutil.boot_time(),
        }
        self._last_net = psutil.net_io_counters()
        self._last_disk = psutil.disk_io_counters()
        self._last_t = time.time()
        self._gpu_tick = 0
        self._gpus = []
        psutil.cpu_percent(percpu=True)
        self.collect()

    # -- processes
    def _processes(self):
        seen = set()
        rows = []
        for p in psutil.process_iter(["pid", "name", "username", "memory_info",
                                      "memory_percent", "num_threads",
                                      "status", "cmdline"]):
            pid = p.info["pid"]
            if IS_WIN and pid == 0:  # "System Idle Process" = idle time
                continue
            seen.add(pid)
            cached = self.procs.get(pid)
            if cached is None:
                self.procs[pid] = p
                try:
                    p.cpu_percent(None)
                except psutil.Error:
                    pass
                cpu = 0.0
            else:
                try:
                    cpu = cached.cpu_percent(None)
                except psutil.Error:
                    continue
            mi = p.info["memory_info"]
            cmd = p.info["cmdline"] or []
            rows.append({
                "pid": pid,
                "name": p.info["name"] or "?",
                "user": p.info["username"] or "?",
                "cpu": round(cpu, 1),
                "mem": round(p.info["memory_percent"] or 0, 1),
                "rss": mi.rss if mi else 0,
                "threads": p.info["num_threads"] or 0,
                "status": p.info["status"] or "",
                "cmd": " ".join(cmd)[:160],
            })
        for pid in list(self.procs):
            if pid not in seen:
                del self.procs[pid]
        return rows

    def _temps(self):
        out = []
        try:
            temps = psutil.sensors_temperatures()
        except (AttributeError, OSError):
            return out
        for chip, entries in temps.items():
            for i, e in enumerate(entries):
                if e.current is None or e.current <= 0:
                    continue
                out.append({
                    "chip": chip,
                    "label": e.label or f"{chip} {i}",
                    "current": round(e.current, 1),
                    "high": e.high, "critical": e.critical,
                })
        return out

    def _cpu_temp(self, temps):
        prefer = ("coretemp", "k10temp", "zenpower", "cpu_thermal",
                  "acpitz", "thinkpad")
        for name in prefer:
            vals = [t for t in temps if t["chip"] == name]
            if vals:
                pkg = [t for t in vals if t["label"].lower().startswith(
                    ("package", "tctl", "tdie"))]
                return (pkg or vals)[0]["current"]
        return temps[0]["current"] if temps else None

    def _disks(self):
        out = []
        seen = set()
        for part in psutil.disk_partitions(all=False):
            if part.device in seen or part.fstype in ("squashfs", "overlay"):
                continue
            if part.mountpoint.startswith(("/snap", "/var/snap", "/boot/efi",
                                           "/System/Volumes", "/private/var/vm")):
                continue
            if IS_WIN and ("cdrom" in part.opts or not part.fstype):
                continue
            seen.add(part.device)
            try:
                u = psutil.disk_usage(part.mountpoint)
            except OSError:
                continue
            out.append({
                "device": part.device, "mount": part.mountpoint,
                "fstype": part.fstype, "total": u.total, "used": u.used,
                "free": u.free, "percent": u.percent,
            })
        return out

    def collect(self):
        now = time.time()
        dt = max(now - self._last_t, 1e-3)
        self._last_t = now

        per_core = psutil.cpu_percent(percpu=True)
        total_cpu = sum(per_core) / len(per_core) if per_core else 0
        freq = None
        try:
            f = psutil.cpu_freq()
            freq = {"current": f.current, "max": f.max} if f else None
        except (OSError, NotImplementedError):
            pass
        try:
            load = psutil.getloadavg()  # emulated on Windows (0 at first)
        except (AttributeError, OSError):
            load = (0, 0, 0)

        vm = psutil.virtual_memory()
        sw = psutil.swap_memory()

        net = psutil.net_io_counters()
        rx = (net.bytes_recv - self._last_net.bytes_recv) / dt
        tx = (net.bytes_sent - self._last_net.bytes_sent) / dt
        self._last_net = net

        dio = psutil.disk_io_counters()
        rd = wr = 0
        if dio and self._last_disk:
            rd = (dio.read_bytes - self._last_disk.read_bytes) / dt
            wr = (dio.write_bytes - self._last_disk.write_bytes) / dt
        self._last_disk = dio

        ifaces = []
        try:
            stats = psutil.net_if_stats()
            addrs = psutil.net_if_addrs()
            for name, st in stats.items():
                if name == "lo" or not st.isup:
                    continue
                ip = next((a.address for a in addrs.get(name, [])
                           if a.family == socket.AF_INET), None)
                ifaces.append({"name": name, "ip": ip, "speed": st.speed})
        except OSError:
            pass

        # GPU: poll every 2 seconds (nvidia-smi is not free)
        if self._gpu_tick % 2 == 0:
            self._gpus = gpu_nvidia() or gpu_sysfs()
        self._gpu_tick += 1

        temps = self._temps()
        battery = None
        try:
            b = psutil.sensors_battery()
            if b:
                battery = {"percent": b.percent, "plugged": b.power_plugged,
                           "secsleft": b.secsleft if b.secsleft and b.secsleft > 0 else None}
        except (AttributeError, OSError):
            pass

        procs = self._processes()
        gpu_util = self._gpus[0]["util"] if self._gpus and self._gpus[0]["util"] is not None else None

        with self.lock:
            self.hist["cpu"].append(round(total_cpu, 1))
            self.hist["mem"].append(round(vm.percent, 1))
            self.hist["rx"].append(rx)
            self.hist["tx"].append(tx)
            self.hist["read"].append(rd)
            self.hist["write"].append(wr)
            self.hist["gpu"].append(gpu_util)
            self.snapshot = {
                "time": now,
                "static": self.static,
                "uptime": now - self.static["boot_time"],
                "cpu": {
                    "total": round(total_cpu, 1),
                    "per_core": [round(c, 1) for c in per_core],
                    "freq": freq, "load": load,
                    "temp": self._cpu_temp(temps),
                },
                "mem": {
                    "total": vm.total, "used": vm.used,
                    "available": vm.available, "percent": vm.percent,
                    "cached": getattr(vm, "cached", 0) + getattr(vm, "buffers", 0),
                    "free": vm.free,
                },
                "swap": {"total": sw.total, "used": sw.used, "percent": sw.percent},
                "net": {"rx": rx, "tx": tx, "rx_total": net.bytes_recv,
                        "tx_total": net.bytes_sent, "ifaces": ifaces},
                "disk_io": {"read": rd, "write": wr},
                "disks": self._disks(),
                "temps": temps,
                "gpus": self._gpus,
                "battery": battery,
                "procs_count": len(procs),
                "procs": procs,
                "history": {k: list(v) for k, v in self.hist.items()},
            }

    def run(self):
        while True:
            t0 = time.time()
            try:
                self.collect()
            except Exception as exc:  # keep the loop alive
                print("collect error:", exc)
            time.sleep(max(0.1, self.interval - (time.time() - t0)))

    def get(self, sort="cpu", limit=40):
        with self.lock:
            snap = dict(self.snapshot)
        key = {"cpu": "cpu", "mem": "rss", "pid": "pid", "name": "name"}.get(sort, "cpu")
        rev = key not in ("pid", "name")
        procs = sorted(snap.get("procs", []),
                       key=lambda r: (r[key].lower() if key == "name" else r[key]),
                       reverse=rev)
        snap["procs"] = procs[:limit]
        return snap


# ------------------------------------------------------------------ server --
def make_handler(collector):
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *a, **kw):
            super().__init__(*a, directory=WEB_DIR, **kw)

        def log_message(self, *args):
            pass

        def do_GET(self):
            if self.path.startswith("/api/stats"):
                from urllib.parse import urlparse, parse_qs
                q = parse_qs(urlparse(self.path).query)
                sort = q.get("sort", ["cpu"])[0]
                try:
                    limit = min(int(q.get("limit", ["40"])[0]), 500)
                except ValueError:
                    limit = 40
                body = json.dumps(collector.get(sort, limit)).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            return super().do_GET()

    return Handler


def start_server(port=8765, interval=1.0):
    collector = Collector(interval)
    threading.Thread(target=collector.run, daemon=True).start()
    httpd = ThreadingHTTPServer(("127.0.0.1", port), make_handler(collector))
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd


def main():
    ap = argparse.ArgumentParser(description="NeonMon backend")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--interval", type=float, default=1.0)
    args = ap.parse_args()
    httpd = start_server(args.port, args.interval)
    print(f"NeonMon: http://127.0.0.1:{httpd.server_address[1]}")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
